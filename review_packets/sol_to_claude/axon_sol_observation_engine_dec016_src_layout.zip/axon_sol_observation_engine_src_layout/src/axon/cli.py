"""Command-line smoke test for Axon Observation Engine MVP."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from axon.config.defaults import ObservationConfig
from axon.engines.observation_engine.observation_engine import ObservationEngine


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Axon Observation Engine MVP smoke test")
    parser.add_argument("--db", type=Path, default=Path("axon_mvp.db"), help="SQLite database path")
    parser.add_argument("--init", action="store_true", help="Initialise schema and device profile")
    parser.add_argument("--once", action="store_true", help="Capture one system snapshot")
    parser.add_argument("--watch", action="store_true", help="Capture repeated snapshots")
    parser.add_argument("--interval", type=float, default=5.0, help="Seconds between watch samples")
    parser.add_argument("--samples", type=int, default=0, help="Number of watch samples; 0 means run until interrupted")
    parser.add_argument("--top-processes", type=int, default=15, help="Number of top CPU/memory processes to store")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    config = ObservationConfig(db_path=args.db, top_process_limit=args.top_processes)
    engine = ObservationEngine(config)

    if args.init or not (args.once or args.watch):
        profile = engine.initialise()
        print(
            json.dumps(
                {
                    "status": "initialised",
                    "device_profile_id": profile.device_profile_id,
                    "hardware_fingerprint": profile.hardware_fingerprint,
                    "created": profile.created,
                    "db": str(args.db),
                    "counts": engine.database_summary(),
                },
                indent=2,
            )
        )

    if args.once:
        result = engine.capture_snapshot(observation_reason="manual_cli_once")
        print(
            json.dumps(
                {
                    "status": "snapshot_captured",
                    "snapshot_id": result.snapshot_id,
                    "device_profile_id": result.device_profile_id,
                    "captured_at": result.captured_at,
                    "cpu_percent_total": (result.payload.get("cpu") or {}).get("percent_total"),
                    "memory_percent": ((result.payload.get("memory") or {}).get("virtual") or {}).get("percent"),
                    "process_count": ((result.payload.get("processes") or {}).get("total_count")),
                    "collector_errors": result.payload.get("collector_errors", []),
                    "counts": engine.database_summary(),
                },
                indent=2,
            )
        )

    if args.watch:
        sample_number = 0
        try:
            while True:
                sample_number += 1
                result = engine.capture_snapshot(observation_reason="manual_cli_watch")
                print(
                    json.dumps(
                        {
                            "status": "snapshot_captured",
                            "sample": sample_number,
                            "snapshot_id": result.snapshot_id,
                            "captured_at": result.captured_at,
                            "cpu_percent_total": (result.payload.get("cpu") or {}).get("percent_total"),
                            "memory_percent": ((result.payload.get("memory") or {}).get("virtual") or {}).get("percent"),
                            "process_count": ((result.payload.get("processes") or {}).get("total_count")),
                        },
                        indent=2,
                    )
                )
                if args.samples and sample_number >= args.samples:
                    break
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("Stopped.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
