"""Runtime configuration for Axon's Observation Engine MVP."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ObservationConfig:
    """Configuration for the Observation Engine.

    The defaults are deliberately conservative. The Observation Engine should be
    safe to run without administrator privileges and should not alter system
    state.
    """

    db_path: Path
    top_process_limit: int = 15
    process_cpu_warmup_seconds: float = 0.1
    include_network_io: bool = True
    include_sensors: bool = True
    include_battery: bool = True
    schema_version: str = "0.2"
    app_version: str = "0.1.0-sol"

    @classmethod
    def from_path(cls, db_path: str | Path) -> "ObservationConfig":
        return cls(db_path=Path(db_path))
