"""Telemetry collectors for Axon's Observation Engine MVP.

Collectors should be conservative. They report what can be safely observed and
avoid inventing values when Windows or hardware does not expose a metric.
"""

from __future__ import annotations

import hashlib
import os
import platform
import socket
import time
import uuid
from datetime import UTC, datetime
from typing import Any

import psutil

from axon.config.defaults import ObservationConfig


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


class ObservationCollector:
    """Collects device profile and point-in-time system snapshots."""

    def __init__(self, config: ObservationConfig) -> None:
        self.config = config

    def collect_device_profile(self) -> dict[str, Any]:
        uname = platform.uname()
        storage_summary = self._collect_storage_summary()
        network_summary = self._collect_network_summary()

        fingerprint_source = "|".join(
            [
                str(uuid.getnode()),
                socket.gethostname(),
                uname.system,
                uname.node,
                uname.machine,
                str(psutil.cpu_count(logical=True)),
                str(psutil.virtual_memory().total),
            ]
        )
        hardware_fingerprint = hashlib.sha256(fingerprint_source.encode("utf-8")).hexdigest()

        return {
            "hardware_fingerprint": hardware_fingerprint,
            "device_name": socket.gethostname(),
            "os_name": uname.system,
            "os_version": uname.version,
            "os_build": uname.release,
            "architecture": uname.machine,
            "cpu_model": uname.processor or platform.processor() or None,
            "cpu_physical_cores": psutil.cpu_count(logical=False),
            "cpu_logical_cores": psutil.cpu_count(logical=True),
            "total_memory_bytes": psutil.virtual_memory().total,
            "gpu_summary_json": [],
            "storage_summary_json": storage_summary,
            "network_summary_json": network_summary,
            "capability_summary_json": {
                "telemetry": {
                    "cpu": True,
                    "memory": True,
                    "disk": True,
                    "processes": True,
                    "network": self.config.include_network_io,
                    "thermal": self.config.include_sensors,
                    "battery": self.config.include_battery,
                    "gpu": False,
                },
                "notes": [
                    "GPU telemetry is not implemented in Sol MVP collector because vendor APIs vary significantly.",
                    "Thermal sensors may be unavailable on Windows through psutil on some hardware.",
                ],
            },
        }

    def collect_system_snapshot(self, observation_reason: str = "scheduled_sample") -> dict[str, Any]:
        errors: list[dict[str, str]] = []

        def safe(name: str, fn):  # type: ignore[no-untyped-def]
            try:
                return fn()
            except Exception as exc:  # pragma: no cover - defensive path depends on host
                errors.append({"collector": name, "error": f"{type(exc).__name__}: {exc}"})
                return None

        snapshot = {
            "captured_at": utc_now(),
            "observation_reason": observation_reason,
            "cpu": safe("cpu", self.collect_cpu),
            "memory": safe("memory", self.collect_memory),
            "disk": safe("disk", self.collect_disk),
            "gpu": [],
            "thermal": safe("thermal", self.collect_thermal) if self.config.include_sensors else {},
            "battery": safe("battery", self.collect_battery) if self.config.include_battery else {},
            "network": safe("network", self.collect_network) if self.config.include_network_io else {},
            "processes": safe("processes", self.collect_processes),
            "startup": {
                "implemented": False,
                "reason": "Startup app enumeration is intentionally deferred until Windows-specific source mapping is implemented.",
            },
            "collector_errors": errors,
            "collector_version": self.config.app_version,
        }
        return snapshot

    def collect_cpu(self) -> dict[str, Any]:
        load_avg = None
        if hasattr(os, "getloadavg"):
            try:
                load_avg = os.getloadavg()
            except OSError:
                load_avg = None

        return {
            "percent_total": psutil.cpu_percent(interval=self.config.process_cpu_warmup_seconds),
            "percent_per_cpu": psutil.cpu_percent(interval=None, percpu=True),
            "frequency": self._asdict_or_none(psutil.cpu_freq()),
            "stats": self._asdict_or_none(psutil.cpu_stats()),
            "load_average": list(load_avg) if load_avg else None,
            "physical_cores": psutil.cpu_count(logical=False),
            "logical_cores": psutil.cpu_count(logical=True),
        }

    def collect_memory(self) -> dict[str, Any]:
        virtual = psutil.virtual_memory()._asdict()
        swap = psutil.swap_memory()._asdict()
        return {
            "virtual": virtual,
            "swap": swap,
        }

    def collect_disk(self) -> dict[str, Any]:
        partitions = []
        for partition in psutil.disk_partitions(all=False):
            item = partition._asdict()
            try:
                item["usage"] = psutil.disk_usage(partition.mountpoint)._asdict()
            except (PermissionError, FileNotFoundError, OSError) as exc:
                item["usage_error"] = f"{type(exc).__name__}: {exc}"
            partitions.append(item)

        io_counters = psutil.disk_io_counters(perdisk=True)
        return {
            "partitions": partitions,
            "io_counters": {name: counter._asdict() for name, counter in io_counters.items()} if io_counters else {},
        }

    def collect_network(self) -> dict[str, Any]:
        counters = psutil.net_io_counters(pernic=True)
        return {
            "io_counters": {name: counter._asdict() for name, counter in counters.items()} if counters else {},
            "connection_count": len(psutil.net_connections(kind="inet")),
        }

    def collect_thermal(self) -> dict[str, Any]:
        temps = {}
        fans = {}
        try:
            temp_data = psutil.sensors_temperatures(fahrenheit=False)
            temps = {name: [entry._asdict() for entry in entries] for name, entries in temp_data.items()}
        except (AttributeError, OSError):
            temps = {}

        try:
            fan_data = psutil.sensors_fans()
            fans = {name: [entry._asdict() for entry in entries] for name, entries in fan_data.items()}
        except (AttributeError, OSError):
            fans = {}

        return {
            "temperatures": temps,
            "fans": fans,
            "availability_note": None
            if temps or fans
            else "Thermal/fan telemetry unavailable through psutil on this device or OS configuration.",
        }

    def collect_battery(self) -> dict[str, Any]:
        try:
            battery = psutil.sensors_battery()
        except (AttributeError, OSError):
            battery = None
        return battery._asdict() if battery else {"available": False}

    def collect_processes(self) -> dict[str, Any]:
        process_rows: list[dict[str, Any]] = []
        attrs = [
            "pid",
            "name",
            "username",
            "status",
            "create_time",
            "cpu_percent",
            "memory_percent",
            "memory_info",
            "num_threads",
            "exe",
            "cmdline",
        ]

        # Prime CPU measurements. This improves the next cpu_percent readings.
        for proc in psutil.process_iter(["pid"]):
            try:
                proc.cpu_percent(interval=None)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        time.sleep(self.config.process_cpu_warmup_seconds)

        for proc in psutil.process_iter(attrs):
            try:
                info = proc.info
                memory_info = info.get("memory_info")
                if memory_info is not None:
                    info["memory_info"] = memory_info._asdict()
                create_time = info.get("create_time")
                if create_time:
                    info["create_time_iso"] = datetime.fromtimestamp(create_time, UTC).isoformat(timespec="seconds").replace("+00:00", "Z")
                info["cmdline"] = self._safe_cmdline(info.get("cmdline"))
                process_rows.append(info)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

        by_cpu = sorted(
            process_rows,
            key=lambda item: float(item.get("cpu_percent") or 0.0),
            reverse=True,
        )[: self.config.top_process_limit]
        by_memory = sorted(
            process_rows,
            key=lambda item: float(item.get("memory_percent") or 0.0),
            reverse=True,
        )[: self.config.top_process_limit]

        return {
            "total_count": len(process_rows),
            "top_by_cpu": by_cpu,
            "top_by_memory": by_memory,
        }

    def _collect_storage_summary(self) -> list[dict[str, Any]]:
        summary = []
        for partition in psutil.disk_partitions(all=False):
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                summary.append(
                    {
                        "device": partition.device,
                        "mountpoint": partition.mountpoint,
                        "fstype": partition.fstype,
                        "total_bytes": usage.total,
                        "used_bytes": usage.used,
                        "free_bytes": usage.free,
                        "percent_used": usage.percent,
                    }
                )
            except (PermissionError, FileNotFoundError, OSError):
                continue
        return summary

    def _collect_network_summary(self) -> list[dict[str, Any]]:
        summary = []
        for interface, addrs in psutil.net_if_addrs().items():
            summary.append(
                {
                    "interface": interface,
                    "address_families": sorted({str(addr.family) for addr in addrs}),
                }
            )
        return summary

    @staticmethod
    def _asdict_or_none(value: Any) -> dict[str, Any] | None:
        if value is None:
            return None
        if hasattr(value, "_asdict"):
            return value._asdict()
        return dict(value)

    @staticmethod
    def _safe_cmdline(value: Any) -> list[str]:
        if not value:
            return []
        if isinstance(value, list):
            # Keep command lines short enough for database readability.
            return [str(part)[:300] for part in value[:20]]
        return [str(value)[:300]]
