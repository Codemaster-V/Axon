"""Small typed boundary models for Axon's MVP engine layer."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


JsonDict = dict[str, Any]


@dataclass(frozen=True)
class DeviceProfileResult:
    device_profile_id: int
    hardware_fingerprint: str
    created: bool


@dataclass(frozen=True)
class SnapshotResult:
    snapshot_id: int
    device_profile_id: int
    captured_at: str
    payload: JsonDict


@dataclass(frozen=True)
class EventResult:
    event_id: int
    event_type: str
    created_at: str
