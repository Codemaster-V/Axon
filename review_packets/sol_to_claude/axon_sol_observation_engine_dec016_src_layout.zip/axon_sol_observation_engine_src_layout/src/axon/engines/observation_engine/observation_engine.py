"""Observation Engine orchestration for Axon's MVP."""

from __future__ import annotations

from axon.engines.observation_engine.collectors import ObservationCollector, utc_now
from axon.config.defaults import ObservationConfig
from axon.core.database import AxonDatabase
from axon.engines.observation_engine.models import DeviceProfileResult, SnapshotResult


class ObservationEngine:
    """Coordinates device profiling, telemetry snapshots, and event logging."""

    def __init__(self, config: ObservationConfig) -> None:
        self.config = config
        self.db = AxonDatabase(config.db_path)
        self.collector = ObservationCollector(config)

    def initialise(self) -> DeviceProfileResult:
        """Initialise schema, seed capabilities, and register current device."""

        self.db.init_schema()
        self.db.seed_capabilities()

        profile_payload = self.collector.collect_device_profile()
        device_profile_id, created = self.db.upsert_device_profile(profile_payload)
        self.db.ensure_user_tolerance_profile(device_profile_id)

        self.db.insert_event(
            source_engine="observation",
            event_type="device_profile_registered" if created else "device_profile_refreshed",
            severity="info",
            device_profile_id=device_profile_id,
            payload={
                "hardware_fingerprint": profile_payload["hardware_fingerprint"],
                "device_name": profile_payload.get("device_name"),
                "created": created,
                "app_version": self.config.app_version,
                "schema_version": self.config.schema_version,
            },
        )
        self.db.insert_event(
            source_engine="observation",
            event_type="capability_registry_seeded",
            severity="info",
            device_profile_id=device_profile_id,
            payload={"note": "MVP safe action boundary seeded; no actions executed by Observation Engine."},
        )

        return DeviceProfileResult(
            device_profile_id=device_profile_id,
            hardware_fingerprint=profile_payload["hardware_fingerprint"],
            created=created,
        )

    def capture_snapshot(self, observation_reason: str = "manual_sample") -> SnapshotResult:
        """Capture and store one system snapshot."""

        profile = self.initialise()
        snapshot_payload = self.collector.collect_system_snapshot(observation_reason=observation_reason)
        snapshot_id = self.db.insert_snapshot(profile.device_profile_id, snapshot_payload)

        error_count = len(snapshot_payload.get("collector_errors", []))
        self.db.insert_event(
            source_engine="observation",
            event_type="system_snapshot_captured",
            severity="warning" if error_count else "info",
            device_profile_id=profile.device_profile_id,
            snapshot_id=snapshot_id,
            payload={
                "observation_reason": observation_reason,
                "collector_errors": snapshot_payload.get("collector_errors", []),
                "top_process_limit": self.config.top_process_limit,
            },
        )

        return SnapshotResult(
            snapshot_id=snapshot_id,
            device_profile_id=profile.device_profile_id,
            captured_at=str(snapshot_payload.get("captured_at") or utc_now()),
            payload=snapshot_payload,
        )

    def database_summary(self) -> dict[str, int]:
        return self.db.table_counts(
            [
                "device_profile",
                "system_snapshot",
                "event_log",
                "goal_record",
                "recommendation_record",
                "action_record",
                "outcome_record",
                "user_tolerance_profile",
                "capability_registry",
            ]
        )
