"""Shared time helpers for Axon."""

from __future__ import annotations

from datetime import UTC, datetime


def utc_now() -> str:
    """Return an ISO-8601 UTC timestamp with millisecond precision."""

    return datetime.now(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")
