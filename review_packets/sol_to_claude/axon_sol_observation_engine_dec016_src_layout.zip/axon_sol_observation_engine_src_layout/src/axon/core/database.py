"""SQLite database layer for Axon's Python MVP.

The database layer deliberately stays simple: plain sqlite3, explicit SQL, and
JSON text fields. This keeps the schema easy for Tyson, Sol, Claude, or a future
C# shell to inspect and replace.
"""

from __future__ import annotations

import json
import sqlite3
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

from axon.engines.observation_engine.models import EventResult

JsonLike = Mapping[str, Any] | list[Any] | str | int | float | bool | None


class AxonDatabase:
    """Small SQLite wrapper for the Axon MVP schema."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA synchronous = NORMAL;")
        return conn


    @staticmethod
    def _project_root() -> Path:
        """Return the repository root when running from the approved src/axon layout."""

        # database.py -> core -> axon -> src -> project root
        return Path(__file__).resolve().parents[3]

    def _schema_path(self) -> Path:
        """Locate the initial SQLite migration file.

        The schema lives outside the Python package so it remains easy for a
        future C# shell or other implementation to inspect and reuse.
        """

        candidates = [
            self._project_root() / "schema" / "migrations" / "001_initial_schema.sql",
            Path.cwd() / "schema" / "migrations" / "001_initial_schema.sql",
        ]
        for candidate in candidates:
            if candidate.exists():
                return candidate
        raise FileNotFoundError(
            "Could not locate schema/migrations/001_initial_schema.sql. "
            "Run commands from the axon-project root or keep the approved folder structure."
        )

    def init_schema(self) -> None:
        schema_path = self._schema_path()
        schema_sql = schema_path.read_text(encoding="utf-8")
        with self.connect() as conn:
            conn.executescript(schema_sql)
            conn.commit()

    def seed_capabilities(self) -> None:
        """Seed the MVP safe action boundary into capability_registry.

        This registry does not mean the actions are implemented yet. It means the
        Decision Engine can reason against an explicit permission/risk boundary.
        """

        capabilities = [
            {
                "capability_key": "startup_app_toggle",
                "capability_name": "Toggle startup app",
                "category": "startup_management",
                "mvp_allowed": 1,
                "requires_admin": 0,
                "requires_user_approval": 1,
                "risk_level": "low",
                "reversibility_level": "automatic",
                "rollback_strategy": "Restore previous startup enabled/disabled state recorded before execution.",
                "implementation_status": "planned",
                "permission_notes": "Implementation may vary by startup source: registry, Startup folder, scheduled task, or app-specific setting.",
                "safety_notes": "Only recommend against a curated allow-list. Never disable security, driver, backup, sync, or input-device utilities in MVP.",
            },
            {
                "capability_key": "process_suspend_safe_list",
                "capability_name": "Suspend curated safe-list process",
                "category": "process_management",
                "mvp_allowed": 1,
                "requires_admin": 0,
                "requires_user_approval": 1,
                "risk_level": "medium",
                "reversibility_level": "automatic",
                "rollback_strategy": "Resume the exact process instance if still present; otherwise record rollback as not required because process ended.",
                "implementation_status": "planned",
                "permission_notes": "Some processes may deny suspend/resume without elevation.",
                "safety_notes": "Never suspend system processes or unknown processes. MVP must use curated safe-list only.",
            },
            {
                "capability_key": "power_profile_change",
                "capability_name": "Change Windows power profile",
                "category": "power_management",
                "mvp_allowed": 1,
                "requires_admin": 0,
                "requires_user_approval": 1,
                "risk_level": "low",
                "reversibility_level": "automatic",
                "rollback_strategy": "Record active power scheme GUID before execution and restore that GUID during rollback.",
                "implementation_status": "planned",
                "permission_notes": "May require powercfg access. Behaviour can vary on managed devices.",
                "safety_notes": "Only switch among existing Windows power plans in MVP. Do not create or modify advanced plan settings.",
            },
            {
                "capability_key": "temporary_optimisation_state",
                "capability_name": "Temporary optimisation state",
                "category": "session_optimisation",
                "mvp_allowed": 1,
                "requires_admin": 0,
                "requires_user_approval": 1,
                "risk_level": "low",
                "reversibility_level": "automatic",
                "rollback_strategy": "Track all temporary changes in action_record and revert them when the optimisation session ends.",
                "implementation_status": "planned",
                "permission_notes": "Depends on the temporary changes included in the state.",
                "safety_notes": "No permanent OS configuration changes in MVP.",
            },
            {
                "capability_key": "cache_cleanup",
                "capability_name": "Clean temporary cache files",
                "category": "storage_cleanup",
                "mvp_allowed": 1,
                "requires_admin": 0,
                "requires_user_approval": 1,
                "risk_level": "low",
                "reversibility_level": "manual",
                "rollback_strategy": "MVP should only delete files that are safe to regenerate. Rollback is not file restoration; it is limited to recorded action audit and skipped unsafe targets.",
                "implementation_status": "planned",
                "permission_notes": "File permissions vary by directory.",
                "safety_notes": "Only target curated temp/cache directories. Never touch user documents, saves, configs, or game mods.",
            },
            {
                "capability_key": "storage_cleanup_recommendation",
                "capability_name": "Storage cleanup recommendation",
                "category": "storage_analysis",
                "mvp_allowed": 1,
                "requires_admin": 0,
                "requires_user_approval": 1,
                "risk_level": "low",
                "reversibility_level": "automatic",
                "rollback_strategy": "Recommendation-only action has no system mutation to roll back.",
                "implementation_status": "planned",
                "permission_notes": "Observation-only unless user approves a later cleanup action.",
                "safety_notes": "Present candidate cleanup areas clearly before execution.",
            },
            {
                "capability_key": "registry_modification",
                "capability_name": "Registry modification",
                "category": "blocked",
                "mvp_allowed": 0,
                "requires_admin": 1,
                "requires_user_approval": 1,
                "risk_level": "blocked",
                "reversibility_level": "not_allowed",
                "rollback_strategy": "Not permitted in MVP.",
                "implementation_status": "blocked",
                "permission_notes": "Explicitly out of scope.",
                "safety_notes": "Blocked by MVP safe action boundary.",
            },
            {
                "capability_key": "driver_modification",
                "capability_name": "Driver modification",
                "category": "blocked",
                "mvp_allowed": 0,
                "requires_admin": 1,
                "requires_user_approval": 1,
                "risk_level": "blocked",
                "reversibility_level": "not_allowed",
                "rollback_strategy": "Not permitted in MVP.",
                "implementation_status": "blocked",
                "permission_notes": "Explicitly out of scope.",
                "safety_notes": "Blocked by MVP safe action boundary.",
            },
            {
                "capability_key": "overclocking_or_undervolting",
                "capability_name": "Overclocking or undervolting",
                "category": "blocked",
                "mvp_allowed": 0,
                "requires_admin": 1,
                "requires_user_approval": 1,
                "risk_level": "blocked",
                "reversibility_level": "not_allowed",
                "rollback_strategy": "Not permitted in MVP.",
                "implementation_status": "blocked",
                "permission_notes": "Explicitly out of scope.",
                "safety_notes": "Blocked by MVP safe action boundary.",
            },
        ]

        with self.connect() as conn:
            conn.executemany(
                """
                INSERT INTO capability_registry (
                    capability_key, capability_name, category, mvp_allowed,
                    requires_admin, requires_user_approval, risk_level,
                    reversibility_level, rollback_strategy,
                    implementation_status, permission_notes, safety_notes
                ) VALUES (
                    :capability_key, :capability_name, :category, :mvp_allowed,
                    :requires_admin, :requires_user_approval, :risk_level,
                    :reversibility_level, :rollback_strategy,
                    :implementation_status, :permission_notes, :safety_notes
                )
                ON CONFLICT(capability_key) DO UPDATE SET
                    capability_name = excluded.capability_name,
                    category = excluded.category,
                    mvp_allowed = excluded.mvp_allowed,
                    requires_admin = excluded.requires_admin,
                    requires_user_approval = excluded.requires_user_approval,
                    risk_level = excluded.risk_level,
                    reversibility_level = excluded.reversibility_level,
                    rollback_strategy = excluded.rollback_strategy,
                    implementation_status = excluded.implementation_status,
                    permission_notes = excluded.permission_notes,
                    safety_notes = excluded.safety_notes,
                    updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
                """,
                capabilities,
            )
            conn.commit()

    def ensure_user_tolerance_profile(self, device_profile_id: int) -> int:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT profile_id FROM user_tolerance_profile WHERE device_profile_id = ?",
                (device_profile_id,),
            ).fetchone()
            if row:
                return int(row["profile_id"])
            cursor = conn.execute(
                "INSERT INTO user_tolerance_profile(device_profile_id) VALUES (?)",
                (device_profile_id,),
            )
            conn.commit()
            return int(cursor.lastrowid)

    def upsert_device_profile(self, profile: Mapping[str, Any]) -> tuple[int, bool]:
        """Insert or update a device profile. Returns (id, created)."""

        payload = dict(profile)
        required = [
            "hardware_fingerprint",
            "device_name",
            "os_name",
            "os_version",
            "os_build",
            "architecture",
            "cpu_model",
            "cpu_physical_cores",
            "cpu_logical_cores",
            "total_memory_bytes",
        ]
        for key in required:
            payload.setdefault(key, None)

        json_fields = [
            "gpu_summary_json",
            "storage_summary_json",
            "network_summary_json",
            "capability_summary_json",
        ]
        for key in json_fields:
            payload[key] = self.to_json(payload.get(key, [] if key.endswith("_summary_json") else {}))

        with self.connect() as conn:
            existing = conn.execute(
                "SELECT device_profile_id FROM device_profile WHERE hardware_fingerprint = ?",
                (payload["hardware_fingerprint"],),
            ).fetchone()
            conn.execute(
                """
                INSERT INTO device_profile (
                    hardware_fingerprint, device_name, os_name, os_version, os_build,
                    architecture, cpu_model, cpu_physical_cores, cpu_logical_cores,
                    total_memory_bytes, gpu_summary_json, storage_summary_json,
                    network_summary_json, capability_summary_json
                ) VALUES (
                    :hardware_fingerprint, :device_name, :os_name, :os_version, :os_build,
                    :architecture, :cpu_model, :cpu_physical_cores, :cpu_logical_cores,
                    :total_memory_bytes, :gpu_summary_json, :storage_summary_json,
                    :network_summary_json, :capability_summary_json
                )
                ON CONFLICT(hardware_fingerprint) DO UPDATE SET
                    device_name = excluded.device_name,
                    os_name = excluded.os_name,
                    os_version = excluded.os_version,
                    os_build = excluded.os_build,
                    architecture = excluded.architecture,
                    cpu_model = excluded.cpu_model,
                    cpu_physical_cores = excluded.cpu_physical_cores,
                    cpu_logical_cores = excluded.cpu_logical_cores,
                    total_memory_bytes = excluded.total_memory_bytes,
                    gpu_summary_json = excluded.gpu_summary_json,
                    storage_summary_json = excluded.storage_summary_json,
                    network_summary_json = excluded.network_summary_json,
                    capability_summary_json = excluded.capability_summary_json,
                    updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
                """,
                payload,
            )
            row = conn.execute(
                "SELECT device_profile_id FROM device_profile WHERE hardware_fingerprint = ?",
                (payload["hardware_fingerprint"],),
            ).fetchone()
            conn.commit()

        if row is None:
            raise RuntimeError("Failed to upsert device profile")
        return int(row["device_profile_id"]), existing is None

    def insert_snapshot(self, device_profile_id: int, snapshot: Mapping[str, Any]) -> int:
        snapshot_payload = dict(snapshot)
        observation_reason = str(snapshot_payload.get("observation_reason", "scheduled_sample"))

        row = {
            "device_profile_id": device_profile_id,
            "observation_reason": observation_reason,
            "cpu_json": self.to_json(snapshot_payload.get("cpu", {})),
            "memory_json": self.to_json(snapshot_payload.get("memory", {})),
            "disk_json": self.to_json(snapshot_payload.get("disk", {})),
            "gpu_json": self.to_json(snapshot_payload.get("gpu", [])),
            "thermal_json": self.to_json(snapshot_payload.get("thermal", {})),
            "battery_json": self.to_json(snapshot_payload.get("battery", {})),
            "network_json": self.to_json(snapshot_payload.get("network", {})),
            "process_json": self.to_json(snapshot_payload.get("processes", {})),
            "startup_json": self.to_json(snapshot_payload.get("startup", {})),
            "raw_payload_json": self.to_json(snapshot_payload),
        }
        with self.connect() as conn:
            cursor = conn.execute(
                """
                INSERT INTO system_snapshot (
                    device_profile_id, observation_reason, cpu_json, memory_json,
                    disk_json, gpu_json, thermal_json, battery_json, network_json,
                    process_json, startup_json, raw_payload_json
                ) VALUES (
                    :device_profile_id, :observation_reason, :cpu_json, :memory_json,
                    :disk_json, :gpu_json, :thermal_json, :battery_json, :network_json,
                    :process_json, :startup_json, :raw_payload_json
                )
                """,
                row,
            )
            conn.commit()
            return int(cursor.lastrowid)

    def insert_event(
        self,
        *,
        source_engine: str,
        event_type: str,
        severity: str = "info",
        payload: Mapping[str, Any] | None = None,
        device_profile_id: int | None = None,
        snapshot_id: int | None = None,
        goal_id: int | None = None,
        recommendation_id: int | None = None,
        action_id: int | None = None,
        outcome_id: int | None = None,
        correlation_id: str | None = None,
    ) -> EventResult:
        with self.connect() as conn:
            cursor = conn.execute(
                """
                INSERT INTO event_log (
                    source_engine, event_type, severity, device_profile_id,
                    snapshot_id, goal_id, recommendation_id, action_id, outcome_id,
                    payload_json, correlation_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    source_engine,
                    event_type,
                    severity,
                    device_profile_id,
                    snapshot_id,
                    goal_id,
                    recommendation_id,
                    action_id,
                    outcome_id,
                    self.to_json(payload or {}),
                    correlation_id,
                ),
            )
            event_id = int(cursor.lastrowid)
            row = conn.execute(
                "SELECT created_at FROM event_log WHERE event_id = ?",
                (event_id,),
            ).fetchone()
            conn.commit()

        return EventResult(
            event_id=event_id,
            event_type=event_type,
            created_at=str(row["created_at"]) if row else "",
        )

    def fetch_recent_snapshots(self, limit: int = 5) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT snapshot_id, device_profile_id, captured_at, observation_reason,
                       cpu_json, memory_json, disk_json, thermal_json, battery_json,
                       network_json, process_json
                FROM system_snapshot
                ORDER BY captured_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [self.row_to_dict(row) for row in rows]

    def fetch_recent_events(self, limit: int = 10) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT event_id, created_at, source_engine, event_type, severity,
                       device_profile_id, snapshot_id, payload_json
                FROM event_log
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [self.row_to_dict(row) for row in rows]

    def table_counts(self, table_names: Iterable[str]) -> dict[str, int]:
        counts: dict[str, int] = {}
        with self.connect() as conn:
            for table in table_names:
                if not table.replace("_", "").isalnum():
                    raise ValueError(f"Unsafe table name: {table!r}")
                row = conn.execute(f"SELECT COUNT(*) AS count FROM {table}").fetchone()
                counts[table] = int(row["count"])
        return counts

    @staticmethod
    def to_json(value: JsonLike) -> str:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

    @staticmethod
    def from_json(value: str | None) -> Any:
        if value is None or value == "":
            return None
        return json.loads(value)

    @staticmethod
    def row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
        result = dict(row)
        for key, value in list(result.items()):
            if key.endswith("_json") and isinstance(value, str):
                result[key] = AxonDatabase.from_json(value)
        return result
