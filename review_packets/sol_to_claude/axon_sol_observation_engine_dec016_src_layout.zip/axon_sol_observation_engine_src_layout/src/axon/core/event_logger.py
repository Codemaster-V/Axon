"""Event logging boundary for Axon's MVP engines.

The Observation Engine currently logs through AxonDatabase directly, but this
small wrapper gives future engines a shared place to write immutable events
without needing to know database internals.
"""

from __future__ import annotations

from typing import Any

from axon.core.database import AxonDatabase
from axon.engines.observation_engine.models import EventResult


class EventLogger:
    """Thin event-writing wrapper around the SQLite database layer."""

    def __init__(self, database: AxonDatabase) -> None:
        self.database = database

    def log(
        self,
        *,
        source_engine: str,
        event_type: str,
        severity: str = "info",
        payload: dict[str, Any] | None = None,
        device_profile_id: int | None = None,
        snapshot_id: int | None = None,
        goal_id: int | None = None,
        recommendation_id: int | None = None,
        action_id: int | None = None,
        outcome_id: int | None = None,
    ) -> EventResult:
        return self.database.insert_event(
            source_engine=source_engine,
            event_type=event_type,
            severity=severity,
            payload=payload or {},
            device_profile_id=device_profile_id,
            snapshot_id=snapshot_id,
            goal_id=goal_id,
            recommendation_id=recommendation_id,
            action_id=action_id,
            outcome_id=outcome_id,
        )
