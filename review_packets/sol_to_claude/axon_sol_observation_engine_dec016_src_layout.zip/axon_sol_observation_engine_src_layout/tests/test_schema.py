from __future__ import annotations

from axon.config.defaults import ObservationConfig
from axon.engines.observation_engine.observation_engine import ObservationEngine


def test_initialise_creates_core_records(tmp_path):
    db_path = tmp_path / "axon_test.db"
    engine = ObservationEngine(ObservationConfig.from_path(db_path))

    profile = engine.initialise()
    counts = engine.database_summary()

    assert profile.device_profile_id > 0
    assert counts["device_profile"] == 1
    assert counts["user_tolerance_profile"] == 1
    assert counts["capability_registry"] >= 6
    assert counts["event_log"] >= 2


def test_capture_snapshot_records_snapshot_and_event(tmp_path):
    db_path = tmp_path / "axon_test.db"
    engine = ObservationEngine(ObservationConfig.from_path(db_path))

    snapshot = engine.capture_snapshot(observation_reason="test")
    counts = engine.database_summary()

    assert snapshot.snapshot_id > 0
    assert snapshot.device_profile_id > 0
    assert counts["system_snapshot"] == 1
    assert counts["event_log"] >= 3
    assert "cpu" in snapshot.payload
    assert "memory" in snapshot.payload
    assert "processes" in snapshot.payload
