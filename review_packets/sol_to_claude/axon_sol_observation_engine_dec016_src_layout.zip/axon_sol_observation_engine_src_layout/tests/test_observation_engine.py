from __future__ import annotations

from axon.config.defaults import ObservationConfig
from axon.engines.observation_engine.observation_engine import ObservationEngine


def test_database_summary_contains_v02_tables(tmp_path):
    engine = ObservationEngine(ObservationConfig.from_path(tmp_path / "axon_test.db"))
    engine.initialise()
    counts = engine.database_summary()

    expected_tables = {
        "device_profile",
        "system_snapshot",
        "event_log",
        "goal_record",
        "recommendation_record",
        "action_record",
        "outcome_record",
        "user_tolerance_profile",
        "capability_registry",
    }
    assert expected_tables.issubset(counts)
