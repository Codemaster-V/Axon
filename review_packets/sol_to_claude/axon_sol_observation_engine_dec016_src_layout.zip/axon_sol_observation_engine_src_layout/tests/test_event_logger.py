from __future__ import annotations

from axon.core.database import AxonDatabase
from axon.core.event_logger import EventLogger


def test_event_logger_writes_event(tmp_path):
    database = AxonDatabase(tmp_path / "axon_test.db")
    database.init_schema()

    logger = EventLogger(database)
    result = logger.log(source_engine="test", event_type="event_logger_smoke_test")

    assert result.event_id > 0
    assert result.event_type == "event_logger_smoke_test"
