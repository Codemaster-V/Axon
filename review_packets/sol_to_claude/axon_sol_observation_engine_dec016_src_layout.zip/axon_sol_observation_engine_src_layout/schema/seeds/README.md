# Schema seeds

Capability registry seed data is currently inserted by `src/axon/core/database.py`. This folder is reserved for SQL seed files if we move seeding out of Python later.
