-- AXON Data Architecture V0.2 — SQLite MVP schema
-- Sol independent implementation
-- Local-first. Conservative. Event-driven.

PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;

CREATE TABLE IF NOT EXISTS schema_migration (
    version TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    description TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS device_profile (
    device_profile_id INTEGER PRIMARY KEY AUTOINCREMENT,
    hardware_fingerprint TEXT NOT NULL UNIQUE,
    device_name TEXT,
    os_name TEXT,
    os_version TEXT,
    os_build TEXT,
    architecture TEXT,
    cpu_model TEXT,
    cpu_physical_cores INTEGER,
    cpu_logical_cores INTEGER,
    total_memory_bytes INTEGER,
    gpu_summary_json TEXT NOT NULL DEFAULT '[]',
    storage_summary_json TEXT NOT NULL DEFAULT '[]',
    network_summary_json TEXT NOT NULL DEFAULT '[]',
    capability_summary_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS system_snapshot (
    snapshot_id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_profile_id INTEGER NOT NULL,
    captured_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    observation_reason TEXT NOT NULL DEFAULT 'scheduled_sample',
    cpu_json TEXT NOT NULL DEFAULT '{}',
    memory_json TEXT NOT NULL DEFAULT '{}',
    disk_json TEXT NOT NULL DEFAULT '{}',
    gpu_json TEXT NOT NULL DEFAULT '[]',
    thermal_json TEXT NOT NULL DEFAULT '{}',
    battery_json TEXT NOT NULL DEFAULT '{}',
    network_json TEXT NOT NULL DEFAULT '{}',
    process_json TEXT NOT NULL DEFAULT '{}',
    startup_json TEXT NOT NULL DEFAULT '{}',
    raw_payload_json TEXT NOT NULL DEFAULT '{}',
    FOREIGN KEY (device_profile_id) REFERENCES device_profile(device_profile_id)
);

CREATE INDEX IF NOT EXISTS idx_system_snapshot_device_time
ON system_snapshot(device_profile_id, captured_at DESC);

CREATE TABLE IF NOT EXISTS event_log (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    source_engine TEXT NOT NULL,
    event_type TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'info',
    device_profile_id INTEGER,
    snapshot_id INTEGER,
    goal_id INTEGER,
    recommendation_id INTEGER,
    action_id INTEGER,
    outcome_id INTEGER,
    payload_json TEXT NOT NULL DEFAULT '{}',
    correlation_id TEXT,
    FOREIGN KEY (device_profile_id) REFERENCES device_profile(device_profile_id),
    FOREIGN KEY (snapshot_id) REFERENCES system_snapshot(snapshot_id)
);

CREATE INDEX IF NOT EXISTS idx_event_log_time
ON event_log(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_event_log_type_time
ON event_log(event_type, created_at DESC);

CREATE TABLE IF NOT EXISTS goal_record (
    goal_id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_profile_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    goal_mode TEXT NOT NULL CHECK(goal_mode IN ('maximise_fps', 'quiet_mode', 'free_storage', 'balanced')),
    user_visible_label TEXT NOT NULL,
    interpreted_goal_json TEXT NOT NULL DEFAULT '{}',
    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'completed', 'cancelled')),
    FOREIGN KEY (device_profile_id) REFERENCES device_profile(device_profile_id)
);

CREATE TABLE IF NOT EXISTS recommendation_record (
    recommendation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    goal_id INTEGER,
    device_profile_id INTEGER NOT NULL,
    generated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    source_snapshot_id INTEGER,
    recommendation_type TEXT NOT NULL,
    title TEXT NOT NULL,
    explanation TEXT NOT NULL,
    expected_benefit_json TEXT NOT NULL DEFAULT '{}',
    risk_level TEXT NOT NULL CHECK(risk_level IN ('low', 'medium', 'high')),
    reversibility_level TEXT NOT NULL CHECK(reversibility_level IN ('automatic', 'manual', 'not_allowed')),
    confidence_of_effectiveness REAL NOT NULL CHECK(confidence_of_effectiveness >= 0.0 AND confidence_of_effectiveness <= 1.0),
    confidence_of_safety REAL NOT NULL CHECK(confidence_of_safety >= 0.0 AND confidence_of_safety <= 1.0),
    simulation_payload_json TEXT NOT NULL DEFAULT '{}',
    status TEXT NOT NULL DEFAULT 'proposed' CHECK(status IN ('proposed', 'approved', 'declined', 'executed', 'rolled_back', 'expired')),
    FOREIGN KEY (goal_id) REFERENCES goal_record(goal_id),
    FOREIGN KEY (device_profile_id) REFERENCES device_profile(device_profile_id),
    FOREIGN KEY (source_snapshot_id) REFERENCES system_snapshot(snapshot_id)
);

CREATE TABLE IF NOT EXISTS action_record (
    action_id INTEGER PRIMARY KEY AUTOINCREMENT,
    recommendation_id INTEGER NOT NULL,
    device_profile_id INTEGER NOT NULL,
    pre_action_snapshot_id INTEGER NOT NULL,
    approved_at TEXT,
    executed_at TEXT,
    action_type TEXT NOT NULL,
    action_payload_json TEXT NOT NULL DEFAULT '{}',
    rollback_payload_json TEXT NOT NULL DEFAULT '{}',
    execution_status TEXT NOT NULL DEFAULT 'pending_approval' CHECK(execution_status IN ('pending_approval', 'approved', 'executed', 'failed', 'rolled_back', 'rollback_failed', 'cancelled')),
    execution_result_json TEXT NOT NULL DEFAULT '{}',
    FOREIGN KEY (recommendation_id) REFERENCES recommendation_record(recommendation_id),
    FOREIGN KEY (device_profile_id) REFERENCES device_profile(device_profile_id),
    FOREIGN KEY (pre_action_snapshot_id) REFERENCES system_snapshot(snapshot_id)
);

CREATE TABLE IF NOT EXISTS outcome_record (
    outcome_id INTEGER PRIMARY KEY AUTOINCREMENT,
    action_id INTEGER NOT NULL,
    device_profile_id INTEGER NOT NULL,
    pre_action_snapshot_id INTEGER NOT NULL,
    post_action_snapshot_id INTEGER,
    measured_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    observation_window_seconds INTEGER,
    outcome_summary TEXT,
    measured_delta_json TEXT NOT NULL DEFAULT '{}',
    environmental_context_json TEXT NOT NULL DEFAULT '{}',
    user_feedback_json TEXT NOT NULL DEFAULT '{}',
    learning_signal_json TEXT NOT NULL DEFAULT '{}',
    FOREIGN KEY (action_id) REFERENCES action_record(action_id),
    FOREIGN KEY (device_profile_id) REFERENCES device_profile(device_profile_id),
    FOREIGN KEY (pre_action_snapshot_id) REFERENCES system_snapshot(snapshot_id),
    FOREIGN KEY (post_action_snapshot_id) REFERENCES system_snapshot(snapshot_id)
);

CREATE TABLE IF NOT EXISTS user_tolerance_profile (
    profile_id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_profile_id INTEGER NOT NULL UNIQUE,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    risk_tolerance TEXT NOT NULL DEFAULT 'conservative' CHECK(risk_tolerance IN ('conservative', 'moderate', 'aggressive')),
    performance_vs_stability INTEGER NOT NULL DEFAULT 50 CHECK(performance_vs_stability >= 0 AND performance_vs_stability <= 100),
    noise_tolerance INTEGER NOT NULL DEFAULT 50 CHECK(noise_tolerance >= 0 AND noise_tolerance <= 100),
    interruption_tolerance INTEGER NOT NULL DEFAULT 50 CHECK(interruption_tolerance >= 0 AND interruption_tolerance <= 100),
    visual_quality_tolerance INTEGER NOT NULL DEFAULT 50 CHECK(visual_quality_tolerance >= 0 AND visual_quality_tolerance <= 100),
    autonomy_preference INTEGER NOT NULL DEFAULT 0 CHECK(autonomy_preference >= 0 AND autonomy_preference <= 100),
    source TEXT NOT NULL DEFAULT 'onboarding',
    refinement_payload_json TEXT NOT NULL DEFAULT '{}',
    FOREIGN KEY (device_profile_id) REFERENCES device_profile(device_profile_id)
);

CREATE TABLE IF NOT EXISTS capability_registry (
    capability_id INTEGER PRIMARY KEY AUTOINCREMENT,
    capability_key TEXT NOT NULL UNIQUE,
    capability_name TEXT NOT NULL,
    category TEXT NOT NULL,
    mvp_allowed INTEGER NOT NULL CHECK(mvp_allowed IN (0, 1)),
    requires_admin INTEGER NOT NULL DEFAULT 0 CHECK(requires_admin IN (0, 1)),
    requires_user_approval INTEGER NOT NULL DEFAULT 1 CHECK(requires_user_approval IN (0, 1)),
    risk_level TEXT NOT NULL CHECK(risk_level IN ('low', 'medium', 'high', 'blocked')),
    reversibility_level TEXT NOT NULL CHECK(reversibility_level IN ('automatic', 'manual', 'not_allowed')),
    rollback_strategy TEXT NOT NULL,
    implementation_status TEXT NOT NULL DEFAULT 'planned' CHECK(implementation_status IN ('planned', 'implemented', 'tested', 'blocked')),
    permission_notes TEXT NOT NULL DEFAULT '',
    safety_notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

INSERT OR IGNORE INTO schema_migration(version, description)
VALUES ('0.2', 'Initial Axon MVP SQLite schema with event log, snapshots, recommendations, outcomes, tolerance profile, and capability registry.');
