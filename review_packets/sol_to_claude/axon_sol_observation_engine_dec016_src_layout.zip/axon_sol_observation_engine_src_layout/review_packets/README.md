# Review packets

Use `sol_to_claude/`, `claude_to_sol/`, and `tyson_decisions/` for structured review and final decision records.
