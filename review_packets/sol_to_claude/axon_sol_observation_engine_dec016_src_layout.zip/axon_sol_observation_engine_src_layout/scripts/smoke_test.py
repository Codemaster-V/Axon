from __future__ import annotations

from pathlib import Path

from axon.config.defaults import ObservationConfig
from axon.engines.observation_engine.observation_engine import ObservationEngine


def main() -> int:
    engine = ObservationEngine(ObservationConfig.from_path(Path("data/axon_mvp_smoke.db")))
    snapshot = engine.capture_snapshot(observation_reason="script_smoke_test")
    print({
        "snapshot_id": snapshot.snapshot_id,
        "device_profile_id": snapshot.device_profile_id,
        "captured_at": snapshot.captured_at,
        "tables": engine.database_summary(),
    })
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
