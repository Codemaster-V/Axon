from __future__ import annotations

from pathlib import Path

from axon.config.defaults import ObservationConfig
from axon.engines.observation_engine.observation_engine import ObservationEngine


def main() -> int:
    engine = ObservationEngine(ObservationConfig.from_path(Path("data/axon_mvp.db")))
    profile = engine.initialise()
    print(f"Initialised Axon database for device_profile_id={profile.device_profile_id}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
