# Axon — Sol Observation Engine MVP, DEC-016 Folder Layout

This is Sol's regenerated independent Python-first implementation of Axon's initial MVP foundation, now using the approved `src/axon/` project structure.

## Included

- SQLite schema for Data Architecture V0.2
- Local-first database layer
- Observation Engine collector
- Immutable event logging
- Point-in-time system snapshots
- Conservative capability registry seed data
- CLI smoke test
- Basic tests

This implementation intentionally does **not** perform optimisation actions. It only observes and records.

## Quick start from the project root

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\activate
python -m pip install -r requirements.txt
python -m axon.cli --db data/axon_mvp.db --init --once
python -m pytest -q
```

If `py -3.12` fails, use:

```powershell
python -m venv .venv
```

## Main active-code layout

```text
src/axon/
  cli.py
  config/defaults.py
  core/database.py
  core/event_logger.py
  core/time_utils.py
  engines/observation_engine/
    collectors.py
    models.py
    observation_engine.py

schema/migrations/001_initial_schema.sql
tests/
```

## Naming rule

Live Python code uses stable importable names such as `observation_engine.py`, `collectors.py`, and `database.py`.

Dated author/version names belong only in review packets, archived outputs, and superseded versions.
